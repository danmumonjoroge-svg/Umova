// src/pos-erp/services/saleService.js
//
// FULL REBUILD. The previous version had three inserts that would fail
// outright (NOT NULL violations: lb_sales.tenant_id/sale_number,
// lb_stock_movements.tenant_id/warehouse_id, lb_payments.tenant_id), plus
// a hand-rolled inventory update that duplicated (worse) what
// applyStockMovement in purchaseService.js already does correctly:
//   - .single() instead of .maybeSingle() — crashed on a product's very
//     first sale if it had never had a GRN (no existing inventory row).
//   - never recalculated stock_status, so lb_inventory.stock_status went
//     stale after every sale even though the schema/dashboard depend on
//     it being current.
//   - never checked track_inventory or allow_negative_stock.
//   - no lb_receipts row was ever created.
//
// This version calls applyStockMovement (imported from purchaseService.js)
// for both the sale and any void, so there's exactly one place that
// touches lb_inventory/lb_stock_movements in the whole app — receiving,
// returns, and now sales all go through it.
//
// FIELD MAPPING — the cart shape from POSPage.jsx uses `cost_price` (not
// `unit_cost`) and includes `selling_mode`/`weight_value` for
// weight/volume/custom items, matching real lb_sale_items columns
// directly now (POSPage.jsx updated alongside this file).
//
// REVERSALS: see reversalService.js / phase29_sale_reversals.sql. Partial refunds (lb_refunds)
// are still not built: that schema is not confirmed.

import { posSupabase as supabase } from './posSupabaseClient';
import { applyStockMovement, getDefaultWarehouseId } from './purchaseService';
import { auditService } from './auditService';
import { folioService } from './folioService';
import { reversalService } from './reversalService';

async function generateSaleNumber() {
  // Same count-based caveat as PO/GRN/return numbering — collision-safe
  // only if RLS scopes the count per tenant. See purchaseService.js.
  const { count } = await supabase.from('lb_sales').select('*', { count: 'exact', head: true });
  return `S-${String((count || 0) + 1).padStart(6, '0')}`;
}

async function generateReceiptNumber() {
  const { count } = await supabase.from('lb_receipts').select('*', { count: 'exact', head: true });
  return `RCT-${String((count || 0) + 1).padStart(6, '0')}`;
}

export const saleService = {
  async getAll({ status, page = 1, limit = 50 } = {}) {
    let q = supabase
      .from('lb_sales')
      .select('*, items:lb_sale_items(*, product:lb_products(id,name,sku))', { count: 'exact' })
      .order('created_at', { ascending: false });
    if (status) q = q.eq('status', status);
    const from = (page - 1) * limit; const to = from + limit - 1; q = q.range(from, to);
    const { data, error, count } = await q; if (error) throw error; return { data, count, page, limit };
  },

  async getById(id) {
    const { data, error } = await supabase
      .from('lb_sales')
      .select('*, items:lb_sale_items(*, product:lb_products(id,name,sku)), payments:lb_payments(*), receipt:lb_receipts(*)')
      .eq('id', id)
      .single();
    if (error) throw error; return data;
  },

  /**
   * @param {object} sale - {
   *   tenant_id, business_id?, branch_id?, cashier_id, shift_id, customer_id?,
   *   items: [{ product_id, quantity, unit_price, cost_price?, discount_amount?,
   *             discount_percent?, tax_amount?, selling_mode?, weight_value?, notes? }],
   *   payments: [{ payment_method, amount, change_amount?, reference_no? }],
   *   notes?, client_reference? // phase11: offline-sync idempotency key
   *   folio_id?, stay_id?       // phase19: charge the sale to a customer folio (no payments)
   *   completed_at?             // offline mode: when the sale really happened (defaults to now)
   *   fromOfflineQueue?         // offline mode: set only by the sync engine -- skips the stock pre-check (see below)
   * }
   * shift_id is required — without it, cashierService.closeShift()'s
   * expected_cash calculation can never find this sale, and the till
   * will always look short/long for the wrong reason. See conversation.
   */
  async create(sale) {
    if (!sale.tenant_id) throw new Error('saleService.create: tenant_id is required.');
    if (!sale.shift_id) throw new Error('saleService.create: shift_id is required (needed for shift cash reconciliation).');
    if (!sale.items?.length) throw new Error('saleService.create: at least one item is required.');
    // Phase 19 (folios): a sale charged to a folio is paid LATER, when the folio is settled. It must
    // carry no payment rows (a CREDIT row would also raise the customer's balance a second time) and
    // must name the customer who owns the folio -- post_sale_to_folio re-checks both on the server.
    if (sale.folio_id) {
      if (!sale.customer_id) throw new Error('saleService.create: a customer is required to charge a folio.');
      if (sale.payments?.length) throw new Error('saleService.create: a sale charged to a folio takes no payment now.');
    }

    // ── Pre-flight stock check, BEFORE writing anything ──
    // Prevents a partially-written sale if one line item would oversell
    // a product that doesn't allow negative stock. Products with
    // track_inventory = false are exempt (nothing to check).
    const warehouseId = await getDefaultWarehouseId(sale.tenant_id);
    // Offline mode: a sale that was made with no internet has ALREADY happened (the goods are gone), so refusing it now
    // because the server's count did not yet know about it would only lose the record. When it comes from the offline
    // queue the check is skipped and the sale is recorded; stock simply shows the true (possibly low/negative) number so
    // the owner can see and fix it. Anything the database itself still refuses comes back as "needs attention".
    for (const item of (sale.fromOfflineQueue ? [] : sale.items)) {
      const { data: product, error: productError } = await supabase
        .from('lb_products')
        .select('track_inventory, allow_negative_stock')
        .eq('id', item.product_id)
        .single();
      if (productError) throw productError;
      if (!product.track_inventory || product.allow_negative_stock) continue;

      const { data: inv } = await supabase
        .from('lb_inventory')
        .select('quantity')
        .eq('product_id', item.product_id)
        .eq('warehouse_id', warehouseId)
        .maybeSingle();
      const available = inv?.quantity || 0;
      if (item.quantity > available) {
        throw new Error(`Insufficient stock for this item — available: ${available}, requested: ${item.quantity}.`);
      }
    }

    const subtotal = sale.items.reduce((sum, i) => sum + i.quantity * i.unit_price, 0);
    const discountTotal = sale.items.reduce((sum, i) => sum + (i.discount_amount || 0), 0);
    const taxTotal = sale.items.reduce((sum, i) => sum + (i.tax_amount || 0), 0);
    const totalAmount = subtotal - discountTotal + taxTotal;

    // Offline-first idempotency (phase11): if this sale carries a
    // client_reference (set when it was created offline and is now
    // syncing), a retried sync must not create a second row. Checked
    // before insert rather than relying only on the unique index, so a
    // retry returns the ALREADY-SYNCED sale cleanly instead of a raw
    // constraint-violation error the sync engine would have to parse.
    if (sale.client_reference) {
      // Scoped to THIS business (audit D-01): never rely on RLS alone to decide whose sale a reference belongs to.
      const { data: existing } = await supabase
        .from('lb_sales')
        .select('id, total_amount')
        .eq('tenant_id', sale.tenant_id)
        .eq('client_reference', sale.client_reference)
        .maybeSingle();
      if (existing) {
        // Same reference but a different total = a DIFFERENT sale that collided with this key (e.g. an older phone that
        // made the same local id). Treating it as "already saved" would silently lose a real sale, so refuse it loudly:
        // it goes to "Needs attention" and the owner sees it.
        if (Math.abs(Number(existing.total_amount) - totalAmount) > 0.005) {
          throw new Error(`Sale reference ${sale.client_reference} is already used by a different sale (total ${existing.total_amount}, this one ${totalAmount}). It was NOT saved - please check it.`);
        }
        // A retried offline sync that was cut off before the folio step finished must finish it now.
        if (sale.folio_id) await folioService.postSale(sale.folio_id, existing.id, sale.cashier_id);
        return this.getById(existing.id);
      }
    }

    const { data: headerData, error: hErr } = await supabase
      .from('lb_sales')
      .insert({
        tenant_id: sale.tenant_id,
        business_id: sale.business_id ?? null,
        branch_id: sale.branch_id ?? null,
        cashier_id: sale.cashier_id,
        shift_id: sale.shift_id,
        customer_id: sale.customer_id ?? null,
        folio_id: sale.folio_id ?? null,
        stay_id: sale.stay_id ?? null,
        sale_number: await generateSaleNumber(),
        status: 'COMPLETED',
        subtotal,
        discount_total: discountTotal,
        tax_total: taxTotal,
        total_amount: totalAmount,
        notes: sale.notes || null,
        completed_at: sale.completed_at || new Date().toISOString(), // offline sales keep the time they were made
        client_reference: sale.client_reference || null,
      })
      .select()
      .single();
    if (hErr) throw hErr;

    const itemRows = sale.items.map((i) => ({
      tenant_id: sale.tenant_id,
      sale_id: headerData.id,
      product_id: i.product_id,
      quantity: i.quantity,
      unit_price: i.unit_price,
      cost_price: i.cost_price || 0,
      discount_amount: i.discount_amount || 0,
      discount_percent: i.discount_percent || 0,
      tax_amount: i.tax_amount || 0,
      total_price: i.quantity * i.unit_price - (i.discount_amount || 0) + (i.tax_amount || 0),
      selling_mode: i.selling_mode || 'PER_UNIT',
      weight_value: i.weight_value ?? null,
      notes: i.notes || null,
    }));
    const { error: iErr } = await supabase.from('lb_sale_items').insert(itemRows);
    if (iErr) throw iErr;

    // Phase 14 (receipts): lb_sale_items has no name column (a receipt
    // reprinted later should show the product's CURRENT name via a join,
    // which is what saleService.getById() already does with
    // `items:lb_sale_items(*, product:lb_products(id,name,sku))`). But
    // the receipt SNAPSHOT below is deliberately point-in-time (see the
    // comment above it), so it needs the name captured NOW, at sale
    // time, not joined later. sale.items[].name is optional -- callers
    // that don't pass it (older code paths, if any) just get a receipt
    // line with no name, not a crash.
    const receiptItems = sale.items.map((i, idx) => ({ ...itemRows[idx], name: i.name || null }));

    if (sale.payments?.length) {
      const paymentRows = sale.payments.map((p) => ({
        tenant_id: sale.tenant_id,
        business_id: sale.business_id ?? null,
        sale_id: headerData.id,
        payment_method: p.payment_method,
        amount: p.amount,
        change_amount: p.change_amount || 0,
        reference_no: p.reference_no || null,
        status: 'COMPLETED',
        created_by: sale.cashier_id,
      }));
      const { error: pErr } = await supabase.from('lb_payments').insert(paymentRows);
      if (pErr) {
        // Phase 39: the database refuses an M-Pesa code that is already on another payment (unique index
        // uq_lb_payments_mpesa_ref). Two tills submitting the same code at once can both pass the pre-check in the
        // till; the loser lands here. At this point nothing else has happened for this sale (no stock moved, no
        // receipt, no payment), so the half-written header/items are removed rather than left looking like a sale
        // with no money behind it. Best effort: if the database will not allow the delete the error below still
        // reaches the cashier and the leftover is visible to the owner as a sale with no payment.
        if (pErr.code === '23505' && /uq_lb_payments_mpesa_ref/.test(`${pErr.message} ${pErr.details || ''}`)) {
          try {
            await supabase.from('lb_sale_items').delete().eq('sale_id', headerData.id);
            await supabase.from('lb_sales').delete().eq('id', headerData.id);
          } catch (cleanupErr) {
            console.error('[saleService.create] could not remove the unpaid sale', headerData.id, cleanupErr);
          }
        }
        throw pErr;
      }
    }

    // Single source of truth for inventory/stock movements — same
    // function goods receiving and supplier returns use.
    for (const item of sale.items) {
      await applyStockMovement({
        tenantId: sale.tenant_id,
        businessId: sale.business_id,
        branchId: sale.branch_id,
        warehouseId,
        productId: item.product_id,
        movementType: 'SALE',
        quantity: -item.quantity, // negative: stock out
        unitCost: item.cost_price || 0,
        referenceId: headerData.id,
        referenceType: 'SALE',
        createdBy: sale.cashier_id,
      });
    }

    // Phase 19: put the sale on the customer's folio. Amounts are read from the stored sale by the
    // server. If this fails the sale is voided (stock goes back) so a charge never exists without its
    // folio line -- the cashier sees an error and can retry, rather than a sale nobody will ever bill.
    if (sale.folio_id) {
      try {
        await folioService.postSale(sale.folio_id, headerData.id, sale.cashier_id);
      } catch (folioErr) {
        try { await reversalService.rollbackNewSale(headerData.id, 'Could not be charged to the folio'); }
        catch (voidErr) { console.error('[saleService.create] folio post failed AND void failed -- sale', headerData.id, 'needs manual review:', voidErr); }
        throw folioErr;
      }
    }

    // Receipt row — content snapshot (items/payments/totals) so a
    // reprint later reflects what was actually sold, even if product
    // prices change afterward. Sending/printing UI is a separate phase;
    // this just makes sure the record exists to build that on top of.
    const { error: rErr } = await supabase.from('lb_receipts').insert({
      tenant_id: sale.tenant_id,
      business_id: sale.business_id ?? null,
      branch_id: sale.branch_id ?? null,
      sale_id: headerData.id,
      receipt_number: await generateReceiptNumber(),
      receipt_type: 'THERMAL',
      receipt_data: {
        sale_number: headerData.sale_number,
        items: receiptItems,
        payments: sale.payments || [],
        subtotal,
        discount_total: discountTotal,
        tax_total: taxTotal,
        total_amount: totalAmount,
        completed_at: headerData.completed_at,
        ...(sale.folio_id ? { charged_to_folio: true, folio_id: sale.folio_id } : {}),
      },
    });
    if (rErr) throw rErr;

    // Audit trail (brief §17/§60's "Sale → ... → Audit" chain). Caught
    // locally rather than left to propagate: by this point the sale,
    // items, payments, stock movement, and receipt are all already
    // committed — if the audit write alone failed and this threw, the
    // cashier would see "Failed to complete sale" for a sale that had
    // already gone through, risking a duplicate on retry. An audit gap
    // is a real problem to notice and fix, but it must not look like a
    // failed sale to the person at the till.
    try {
      await auditService.log({
        tenantId: sale.tenant_id,
        actorId: sale.cashier_id,
        action: 'SALE_COMPLETED',
        entityType: 'lb_sales',
        entityId: headerData.id,
        metadata: {
          sale_number: headerData.sale_number,
          total_amount: totalAmount,
          discount_total: discountTotal,
          payment_methods: (sale.payments || []).map((p) => p.payment_method),
          customer_id: sale.customer_id ?? null,
          folio_id: sale.folio_id ?? null,
        },
      });
    } catch (auditErr) {
      console.error('[saleService.create] audit log failed (sale itself succeeded):', auditErr);
    }

    return this.getById(headerData.id);
  },

  // voidSale() was removed: it changed the sale from the browser (not atomic, no permission, could run
  // twice, never touched cash or the customer's balance). Reversals now go through reversalService
  // (request -> approval -> one atomic database function). The only internal use left is
  // rolling back a sale that could not be posted to its folio, via pos_rollback_new_sale.

};
