// src/components/Auth/AuthPage.js
// FIRST-TIME SETUP FLOW (SIMPLIFIED):
//   Member enters: member number + national ID + new password + confirm. That's it.
//   The `activate-member` edge function (service role) verifies the ID server-side,
//   attaches the password to the EXISTING members row (no new member is ever created),
//   and this page then signs the member in automatically. No email link, no second step.

import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  Eye, EyeOff, Shield, Loader2, AlertCircle, CheckCircle,
  Lock, User, ArrowLeft, RefreshCcw, CreditCard,
} from "lucide-react";
import { supabase } from "../../supabaseClient";
import umovaEmblem from "../../assets/brand/umova-emblem-small.png";
import FingerprintLogin from "../../security/FingerprintLogin";

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
const getPasswordStrength = (pass) => {
  if (!pass) return { score: 0, label: "", color: "" };
  let score = 0;
  if (pass.length >= 8)           score++;
  if (/[A-Z]/.test(pass))         score++;
  if (/[a-z]/.test(pass))         score++;
  if (/[0-9]/.test(pass))         score++;
  if (/[^A-Za-z0-9]/.test(pass))  score++;
  const map = {
    0: { label: "",            color: "" },
    1: { label: "Very Weak",   color: "bg-red-500" },
    2: { label: "Weak",        color: "bg-orange-500" },
    3: { label: "Fair",        color: "bg-yellow-500" },
    4: { label: "Strong",      color: "bg-lime-500" },
    5: { label: "Very Strong", color: "bg-green-600" },
  };
  return { score, ...map[score] };
};

const validatePassword = (pass) => {
  if (pass.length < 8)      return "Password must be at least 8 characters";
  if (!/[A-Z]/.test(pass))  return "Password must contain an uppercase letter";
  if (!/[a-z]/.test(pass))  return "Password must contain a lowercase letter";
  if (!/[0-9]/.test(pass))  return "Password must contain a number";
  return null;
};

const formatMemberNo = (val) => val.toUpperCase().replace(/[^A-Z0-9-]/g, "");

const isPasswordSet = (val) => val === true || val === "true";

const RESET_MESSAGES = {
  INVALID_DETAILS:  "Member number and ID number do not match our records.",
  NOT_ACTIVATED:    "No password set yet. Use First Time Setup instead.",
  ACCOUNT_INACTIVE: "This account is not active. Contact the SACCO office.",
  NO_EMAIL:         "No email on file. Contact the SACCO office.",
  RATE_LIMITED:     "Too many attempts. Please wait 15 minutes and try again.",
  SERVER_ERROR:     "Could not send the reset email right now. Please try again.",
};

const ACTIVATE_MESSAGES = {
  INVALID_DETAILS: "Member number and National ID do not match our records.",
  ALREADY_ACTIVE:  "This account is already activated. Log in, or use Forgot Password.",
  ACCOUNT_INACTIVE:"This account is not active. Contact the SACCO office.",
  NO_EMAIL:        "No email address is linked to your account. Contact the SACCO office to add one.",
  WEAK_PASSWORD:   "Password must be at least 8 characters with an uppercase letter, a lowercase letter and a number.",
  RATE_LIMITED:    "Too many attempts. Please wait 15 minutes and try again.",
  SERVER_ERROR:    "Could not activate your account right now. Please try again, or contact the SACCO office.",
};

// ─────────────────────────────────────────────
// PASSWORD INPUT
// ─────────────────────────────────────────────
const PasswordInput = ({ value, onChange, placeholder, show, onToggle, icon: Icon }) => (
  <div className="relative">
    {Icon && <Icon size={18} className="absolute left-4 top-4 text-slate-400 pointer-events-none" />}
    <input
      type={show ? "text" : "password"}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={`w-full h-14 ${Icon ? "pl-12" : "pl-4"} pr-14 rounded-2xl border border-slate-300 focus:border-green-700 focus:ring-4 focus:ring-green-100 outline-none text-slate-800 placeholder-slate-400 transition`}
    />
    <button type="button" onClick={onToggle}
      className="absolute right-4 top-4 text-slate-400 hover:text-slate-600 transition" tabIndex={-1}>
      {show ? <EyeOff size={18} /> : <Eye size={18} />}
    </button>
  </div>
);

// ─────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────
export default function AuthPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [mode, setMode] = useState("login");

  // If UnifiedLogin.js (the primary /login screen) detected this member
  // hasn't set a password yet, it hands off here with state instead of
  // making them retype their member number.
  useEffect(() => {
    if (location.state?.mode === "setup" && location.state?.memberNo) {
      setSetupMemberNo(location.state.memberNo);
      setMode("setup");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Login States
  const [memberNo, setMemberNo] = useState("");
  const [password, setPassword] = useState("");

  // Setup States
  const [setupMemberNo, setSetupMemberNo] = useState("");
  const [setupIdNumber, setSetupIdNumber] = useState("");
  const [setupPassword, setSetupPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Forgot States
  const [resetMemberNo, setResetMemberNo] = useState("");
  const [resetIdNumber, setResetIdNumber] = useState("");

  // UI Engine States
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showSetupPassword, setShowSetupPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const passwordStrength = getPasswordStrength(setupPassword);
  const clearMessages = () => { setError(""); setSuccess(""); };
  const switchMode = (m) => { clearMessages(); setMode(m); };

  // ─────────────────────────────────────────────
  // LOGIN FLOW
  // ─────────────────────────────────────────────
  const handleLogin = async (e) => {
    e.preventDefault();
    clearMessages();

    if (!memberNo.trim() || !password) {
      setError("Enter your member number and password");
      return;
    }

    setLoading(true);
    try {
      // Server-side lookup returns only what login needs (no national_id, no other columns).
      const { data: member, error: memberError } = await supabase
        .rpc("member_login_lookup", { p_member_no: memberNo.trim().toUpperCase() });

      if (memberError) { setError("Failed to look up member. Please try again."); return; }
      if (!member)     { setError("Member number not found."); return; }

      if (member.status === "inactive")  { setError("Your account is inactive. Contact the SACCO office."); return; }
      if (member.status === "suspended") { setError("Your account is suspended. Contact the SACCO office."); return; }

      if (!isPasswordSet(member.password_set)) {
        setSetupMemberNo(member.member_no);
        setError("You haven't activated your account yet. Complete setup below.");
        setMode("setup");
        return;
      }

      if (!member.email) { setError("No email on file. Contact the SACCO office."); return; }

      const { error: authError } = await supabase.auth.signInWithPassword({
        email: member.email,
        password,
      });

      if (authError) {
        if (authError.message.toLowerCase().includes("invalid login credentials")) {
          setError("Incorrect password. Please try again.");
        } else if (authError.message.toLowerCase().includes("email not confirmed")) {
          setError("Please confirm your email address first — check your inbox.");
        } else {
          setError(authError.message);
        }
        return;
      }

      setSuccess(`Welcome back, ${member.name || "Member"}!`);
      setTimeout(() => navigate("/redirect", { replace: true }), 800);

    } catch (err) {
      console.error("Login error:", err);
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // ─────────────────────────────────────────────
  // FIRST TIME SETUP FLOW
  // All verification happens on the server. The browser never reads national_id.
  // ─────────────────────────────────────────────
  const handleSetup = async (e) => {
    e.preventDefault();
    clearMessages();

    if (!setupMemberNo.trim() || !setupIdNumber.trim() || !setupPassword || !confirmPassword) {
      setError("All fields are required"); return;
    }
    const pwErr = validatePassword(setupPassword);
    if (pwErr) { setError(pwErr); return; }
    if (setupPassword !== confirmPassword) { setError("Passwords do not match"); return; }

    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke("activate-member", {
        body: {
          memberNo:   setupMemberNo.trim().toUpperCase(),
          nationalId: setupIdNumber.trim(),
          password:   setupPassword,
        },
      });

      // supabase-js hides the JSON body of non-2xx replies inside error.context
      let res = data;
      if (fnError) {
        try { res = await fnError.context.json(); } catch { res = null; }
      }

      if (!res?.ok) {
        setError(ACTIVATE_MESSAGES[res?.reason] || "Could not activate your account. Please try again.");
        return;
      }

      // Account is ready: sign straight in with the password they just chose.
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: res.email,
        password: setupPassword,
      });

      setSetupPassword(""); setConfirmPassword(""); setSetupIdNumber("");

      if (signInError) {
        setSuccess("Account activated! Please log in with your member number and password.");
        setTimeout(() => switchMode("login"), 1500);
        return;
      }

      setSuccess("Account activated! Signing you in…");
      setTimeout(() => navigate("/redirect", { replace: true }), 600);

    } catch (err) {
      console.error("Setup error:", err);
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // ─────────────────────────────────────────────
  // FORGOT PASSWORD FLOW
  // ─────────────────────────────────────────────
  const handleForgotPassword = async (e) => {
    e.preventDefault();
    clearMessages();

    if (!resetMemberNo.trim() || !resetIdNumber.trim()) {
      setError("Enter your member number and ID number"); return;
    }

    setLoading(true);
    try {
      // Verification and the email are handled on the server; the browser never sees national_id or the email.
      const { data, error: fnError } = await supabase.functions.invoke("member-forgot-password", {
        body: { memberNo: resetMemberNo.trim().toUpperCase(), nationalId: resetIdNumber.trim() },
      });
      let res = data;
      if (fnError) { try { res = await fnError.context.json(); } catch { res = null; } }

      if (!res?.ok) {
        setError(RESET_MESSAGES[res?.reason] || "Could not send the reset email. Please try again.");
        return;
      }
      setSuccess(`Reset link sent to ${res.maskedEmail}. Check your inbox and follow the link.`);
      setResetMemberNo(""); setResetIdNumber("");

    } catch (err) {
      console.error("Reset error:", err);
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // ─────────────────────────────────────────────
  // JSX LAYOUT
  // ─────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 p-8">

        {/* HEADER */}
        <div className="text-center mb-8">
          <div className="w-28 h-24 mx-auto flex items-center justify-center mb-3">
            <img src={umovaEmblem} alt="Umova" className="w-full h-full object-contain" />
          </div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tight">Umova SACCO</h1>
          <p className="text-slate-500 mt-1 text-sm">
            {mode === "login"  && "Secure Member Authentication"}
            {mode === "setup"  && "First Time Account Setup"}
            {mode === "forgot" && "Reset Your Password"}
          </p>
        </div>

        {/* ALERTS DISPLAY */}
        {error && (
          <div className="mb-5 bg-red-50 border border-red-200 p-4 rounded-2xl flex gap-3 items-start">
            <AlertCircle className="text-red-500 mt-0.5 shrink-0" size={18} />
            <p className="text-red-700 text-sm leading-relaxed">{error}</p>
          </div>
        )}
        {success && (
          <div className="mb-5 bg-green-50 border border-green-200 p-4 rounded-2xl flex gap-3 items-start">
            <CheckCircle className="text-green-600 mt-0.5 shrink-0" size={18} />
            <p className="text-green-700 text-sm leading-relaxed">{success}</p>
          </div>
        )}

        {/* ── LOGIN FORM ── */}
        {mode === "login" && (
          <form onSubmit={handleLogin} className="space-y-5" noValidate>
            <div>
              <label className="block mb-2 font-semibold text-sm text-slate-700">Member Number</label>
              <div className="relative">
                <User size={18} className="absolute left-4 top-4 text-slate-400 pointer-events-none" />
                <input type="text" value={memberNo}
                  onChange={(e) => setMemberNo(formatMemberNo(e.target.value))}
                  placeholder="UI-0001" maxLength={12} autoComplete="username"
                  className="w-full h-14 pl-12 rounded-2xl border border-slate-300 focus:border-green-700 focus:ring-4 focus:ring-green-100 outline-none text-slate-800 placeholder-slate-400 transition font-mono tracking-wider" />
              </div>
            </div>
            <div>
              <label className="block mb-2 font-semibold text-sm text-slate-700">Password</label>
              <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password" show={showPassword}
                onToggle={() => setShowPassword(v => !v)} icon={Lock} />
            </div>
            <button type="submit" disabled={loading}
              className="w-full h-14 rounded-2xl bg-green-700 hover:bg-green-800 disabled:opacity-60 text-white font-bold flex items-center justify-center gap-3 transition shadow-md">
              {loading ? <><Loader2 className="animate-spin" size={20} />Authenticating...</> : <><Shield size={20} />Login</>}
            </button>
            <div className="flex items-center justify-between pt-2">
              <button type="button" onClick={() => switchMode("setup")}
                className="text-green-700 hover:text-green-900 font-semibold text-sm transition">
                First Time Setup
              </button>
              <button type="button" onClick={() => switchMode("forgot")}
                className="text-green-700 hover:text-green-900 font-semibold text-sm transition">
                Forgot Password?
              </button>
            </div>
          </form>
        )}

        {/* Phone app only, and only once fingerprint was turned on for this phone; renders nothing otherwise. */}
        {mode === "login" && (
          <FingerprintLogin
            service="finance"
            client={supabase}
            onSignedIn={() => {
              clearMessages();
              setSuccess("Signed in with fingerprint.");
              setTimeout(() => navigate("/redirect", { replace: true }), 500);
            }}
          />
        )}

        {/* Separate service: Chama has its own accounts and its own login. */}
        {mode === "login" && (
          <div className="mt-6 text-center text-xs text-slate-500">
            Chama member?{" "}
            <button type="button" onClick={() => navigate("/chama/login")}
              className="text-green-700 font-semibold hover:underline">
              Sign in to Chama
            </button>
          </div>
        )}

        {/* ── FIRST TIME SETUP FORM ── */}
        {mode === "setup" && (
          <form onSubmit={handleSetup} className="space-y-4" noValidate>
            <button type="button" onClick={() => switchMode("login")}
              className="flex items-center gap-2 text-slate-500 hover:text-slate-700 text-sm mb-2 transition">
              <ArrowLeft size={16} />Back to Login
            </button>

            <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 rounded-2xl p-4 border border-slate-200">
              Enter your member number and National ID, then choose a password. That's all.
            </p>

            <div>
              <label className="block mb-1.5 font-semibold text-sm text-slate-700">Member Number</label>
              <div className="relative">
                <CreditCard size={18} className="absolute left-4 top-4 text-slate-400 pointer-events-none" />
                <input type="text" value={setupMemberNo}
                  onChange={(e) => setSetupMemberNo(formatMemberNo(e.target.value))}
                  placeholder="UI-0001" maxLength={12} autoComplete="off"
                  className="w-full h-14 pl-12 rounded-2xl border border-slate-300 focus:border-green-700 focus:ring-4 focus:ring-green-100 outline-none text-slate-800 placeholder-slate-400 transition font-mono tracking-wider" />
              </div>
            </div>

            <div>
              <label className="block mb-1.5 font-semibold text-sm text-slate-700">National ID Number</label>
              <div className="relative">
                <User size={18} className="absolute left-4 top-4 text-slate-400 pointer-events-none" />
                <input type="text" value={setupIdNumber}
                  onChange={(e) => setSetupIdNumber(e.target.value.replace(/\D/g, ""))}
                  placeholder="12345678" maxLength={8} autoComplete="off"
                  className="w-full h-14 pl-12 rounded-2xl border border-slate-300 focus:border-green-700 focus:ring-4 focus:ring-green-100 outline-none text-slate-800 placeholder-slate-400 transition" />
              </div>
            </div>

            <div>
              <label className="block mb-1.5 font-semibold text-sm text-slate-700">New Password</label>
              <PasswordInput value={setupPassword} onChange={(e) => setSetupPassword(e.target.value)}
                placeholder="Min 8 chars, upper, lower, number"
                show={showSetupPassword} onToggle={() => setShowSetupPassword(v => !v)} icon={Lock} />
                            {setupPassword.length > 0 && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1,2,3,4,5].map(i => (
                      <div key={i} className={`h-1.5 flex-1 rounded-full transition-all ${i <= passwordStrength.score ? passwordStrength.color : "bg-slate-200"}`} />
                    ))}
                  </div>
                  <p className="text-xs text-slate-500">{passwordStrength.label}</p>
                </div>
              )}
            </div>

            <div>
              <label className="block mb-1.5 font-semibold text-sm text-slate-700">Confirm Password</label>
              <PasswordInput value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter password"
                show={showConfirmPassword} onToggle={() => setShowConfirmPassword(v => !v)} icon={Lock} />
              {confirmPassword.length > 0 && (
                <p className={`text-xs mt-1.5 ${setupPassword === confirmPassword ? "text-green-600" : "text-red-500"}`}>
                  {setupPassword === confirmPassword ? "✓ Passwords match" : "✗ Passwords do not match"}
                </p>
              )}
            </div>

            <button type="submit" disabled={loading}
              className="w-full h-14 rounded-2xl bg-green-700 hover:bg-green-800 disabled:opacity-60 text-white font-bold flex items-center justify-center gap-3 transition shadow-md">
              {loading ? <><Loader2 className="animate-spin" size={20} />Activating...</> : <><Shield size={20} />Activate &amp; Sign In</>}
            </button>
          </form>
        )}

        {/* ── FORGOT PASSWORD FORM ── */}
        {mode === "forgot" && (
          <form onSubmit={handleForgotPassword} className="space-y-4" noValidate>
            <button type="button" onClick={() => switchMode("login")}
              className="flex items-center gap-2 text-slate-500 hover:text-slate-700 text-sm mb-2 transition">
              <ArrowLeft size={16} />Back to Login
            </button>

            <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 rounded-2xl p-4 border border-slate-200">
              Enter your member number and national ID. We'll send a password reset link to your registered email.
            </p>

            <div>
              <label className="block mb-1.5 font-semibold text-sm text-slate-700">Member Number</label>
              <div className="relative">
                <CreditCard size={18} className="absolute left-4 top-4 text-slate-400 pointer-events-none" />
                <input type="text" value={resetMemberNo}
                  onChange={(e) => setResetMemberNo(formatMemberNo(e.target.value))}
                  placeholder="UI-0001" maxLength={12} autoComplete="off"
                  className="w-full h-14 pl-12 rounded-2xl border border-slate-300 focus:border-green-700 focus:ring-4 focus:ring-green-100 outline-none text-slate-800 placeholder-slate-400 transition font-mono tracking-wider" />
              </div>
            </div>

            <div>
              <label className="block mb-1.5 font-semibold text-sm text-slate-700">National ID Number</label>
              <div className="relative">
                <User size={18} className="absolute left-4 top-4 text-slate-400 pointer-events-none" />
                <input type="text" value={resetIdNumber}
                  onChange={(e) => setResetIdNumber(e.target.value.replace(/\D/g, ""))}
                  placeholder="12345678" maxLength={8} autoComplete="off"
                  className="w-full h-14 pl-12 rounded-2xl border border-slate-300 focus:border-green-700 focus:ring-4 focus:ring-green-100 outline-none text-slate-800 placeholder-slate-400 transition" />
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="w-full h-14 rounded-2xl bg-green-700 hover:bg-green-800 disabled:opacity-60 text-white font-bold flex items-center justify-center gap-3 transition shadow-md">
              {loading ? <><Loader2 className="animate-spin" size={18} />Sending...</> : <><RefreshCcw size={18} />Send Reset Email</>}
            </button>
          </form>
        )}

      </div>
    </div>
  );
}