import { useEffect, useState } from "react";
import { supabase } from "../../supabaseClient";
import "./Members.css";
import { useAuth } from "../../Context/AuthContext";

import {
  runRiskEngine,
  getParCategory,
} from "../../utils/riskEngine";

/* ======================================================
   ACCOUNT CODES
====================================================== */

const SAVINGS_ACCOUNT = "1018";
const LOAN_ACCOUNT = "1011";
const LOAN_INTEREST_ACCOUNT = "1020";
const SHARES_ACCOUNT = "1012";

const INSTALLMENT_DAYS = 30;

/* ======================================================
   FORMAT
====================================================== */

const format = (n) =>
  Number(n || 0).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

/* ======================================================
   HELPERS
   - Supabase returns at most 1000 rows per request. The old code
     fetched members and the whole general ledger in ONE request, so
     once the ledger passed 1000 rows every balance was silently wrong.
     fetchAll() pages through until everything is loaded.
   - memberKey() makes "ui-0001 " and "UI-0001" the same member.
====================================================== */

const PAGE_SIZE = 1000;

async function fetchAll(table, columns = "*") {
  let from = 0;
  let all = [];
  for (;;) {
    const { data, error } = await supabase
      .from(table)
      .select(columns)
      .order("id", { ascending: true })
      .range(from, from + PAGE_SIZE - 1);
    if (error) throw error;
    all = all.concat(data || []);
    if (!data || data.length < PAGE_SIZE) break;
    from += PAGE_SIZE;
  }
  return all;
}

const memberKey = (v) => String(v || "").trim().toUpperCase();

const REASONS = {
  FORBIDDEN: "You are not allowed to do this.",
  NAME_REQUIRED: "Name is required.",
  INVALID_NATIONAL_ID: "National ID must be 7 or 8 digits.",
  EMAIL_REQUIRED: "Email is required (the member needs it to activate their account).",
  DUPLICATE_NATIONAL_ID: "A member with this National ID already exists.",
  DUPLICATE_EMAIL: "Another member already uses this email address.",
  ALREADY_PROCESSED: "This application was already approved or rejected.",
  NOT_FOUND: "Application not found.",
  // member editing (admin_update_member)
  FORBIDDEN_FIELD: "Only an administrator can change that field.",
  FIELD_NOT_ALLOWED: "That field cannot be edited here.",
  INVALID_REQUEST: "Invalid request.",
  INVALID_MEMBER_NO: "Member number may only contain letters, numbers and dashes (e.g. UI-0123), 3 to 20 characters.",
  DUPLICATE_MEMBER_NO: "Another member already has that member number.",
  DUPLICATE_STAFF_NO: "That number belongs to a staff user. Choose a different member number.",
  INVALID_EMAIL: "Enter a valid email address.",
  EMAIL_LOCKED: "This member has already activated their account, so their email cannot be changed here (it is their login). Contact the system administrator.",
  INVALID_STATUS: "Status must be active, inactive or suspended.",
  TOO_LONG: "One of the values is too long.",
};

/* ---- member editing helpers ---- */
const EDIT_FIELDS = ["member_no", "name", "national_id", "email", "phone", "branch", "occupation", "status"];
const STATUS_OPTIONS = ["active", "inactive", "suspended"];
const EDIT_ROLES = ["staff", "manager"]; // admins/superadmins are covered by isAdmin; the server enforces this too

const normField = (k, v) => {
  const t = String(v ?? "").trim();
  if (k === "member_no") return t.toUpperCase();
  if (k === "email" || k === "status") return t.toLowerCase();
  return t;
};

const editErrorText = (res) => {
  if (!res) return "Could not save. Please try again.";
  if (res.reason === "FK_NOT_CASCADING")
    return `Another table (${res.table || "unknown"}) points at this member number and is not set to follow a change. Nothing was changed. Ask your developer to apply the ON UPDATE CASCADE fix.`;
  if (res.reason === "UPDATE_FAILED")
    return `The change was rejected${res.table ? ` while updating ${res.table}` : ""}, so nothing was changed. ${res.detail || ""}`.trim();
  return REASONS[res.reason] || "Could not save. Please try again.";
};

/* ======================================================
   COMPONENT
====================================================== */

export default function Members() {

  const { role, isAdmin } = useAuth();
  const canEdit = !!isAdmin || EDIT_ROLES.includes(String(role || "").toLowerCase());

  const [members, setMembers] = useState([]);
  const [selected, setSelected] = useState(null);

  const [loading, setLoading] = useState(false);

  const [searchType, setSearchType] =
    useState("member_no");

  const [searchText, setSearchText] =
    useState("");

  /* ================= APPLICATIONS ================= */

  const [applications, setApplications] = useState([]);
  const [appsLoading, setAppsLoading] = useState(false);
  const [showApplications, setShowApplications] = useState(false);

  /* ================= ADD MEMBER MODAL ================= */

  const [showAddMember, setShowAddMember] = useState(false);
  const [addForm, setAddForm] = useState({
    name: "",
    national_id: "",
    email: "",
    phone: "",
    branch: "",
  });
  const [addSaving, setAddSaving] = useState(false);
  const [addError, setAddError] = useState("");

  /* ================= FEEDBACK / DOUBLE-CLICK GUARDS ================= */

  const [loadError, setLoadError] = useState("");
  const [notice, setNotice] = useState("");
  const [busyId, setBusyId] = useState(null);

  /* ================= EDIT MEMBER ================= */

  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState("");

  /* ======================================================
     LOAD MEMBERS + LEDGER
  ====================================================== */

  const load = async () => {

    setLoading(true);

    let memberData;
    let ledger;

    try {
      memberData = await fetchAll("members");
      ledger = await fetchAll(
        "general_ledger",
        "id, member_no, name, debit_account_id, credit_account_id, amount, date, created_at"
      );
      setLoadError("");
    } catch (err) {
      console.error("Members load failed:", err);
      setLoadError("Could not load members: " + (err?.message || err));
      setLoading(false);
      return;
    }

    /* ======================================================
       MEMBER MAP
    ====================================================== */

    const map = {};

    /* ======================================================
       INITIALIZE
    ====================================================== */

    (memberData || []).forEach((m) => {

      map[memberKey(m.member_no) || String(m.id)] = {

        ...m,

        savings: 0,
        shares: 0,

        loanIssued: 0,
        loanPaid: 0,

        interestPaid: 0,

        loanBalance: 0,

        arrearsDays: 0,
        parCategory: "Performing",

        lastPaymentDate: null,
        lastLoanIncreaseDate: null,

        repaymentRatio: 0,

        refinanceCount: 0,
        activeLoans: 1,

        monthlySavings: 0,
        savingsFrequency: 0,

        dormantMonths: 0,
        savingsTrend: "stable",

        activityConsistency: 80,

        withdrawalFrequency: 0,

        suspiciousActivity: false,
        rapidWithdrawals: false,

        score: 0,
        riskLabel: "Unknown",

      };
    });

    /* ======================================================
       PROCESS LEDGER
    ====================================================== */

    ledger.forEach((row) => {

      const member =
        memberKey(row.member_no);

      if (!member) return;

      if (!map[member]) {

        map[member] = {

          member_no: member,
          ledgerOnly: true, // ledger rows exist for a member number that is NOT in the members table
          name:
            row.name ||
            "Unknown",

          savings: 0,
          shares: 0,

          loanIssued: 0,
          loanPaid: 0,

          interestPaid: 0,

          loanBalance: 0,

          arrearsDays: 0,
          parCategory:
            "Performing",

          lastPaymentDate: null,
          lastLoanIncreaseDate:
            null,

          repaymentRatio: 0,

          refinanceCount: 0,
          activeLoans: 1,

          monthlySavings: 0,
          savingsFrequency: 0,

          dormantMonths: 0,
          savingsTrend:
            "stable",

          activityConsistency: 80,

          withdrawalFrequency: 0,

          suspiciousActivity: false,
          rapidWithdrawals: false,

          score: 0,
          riskLabel: "Unknown",

        };
      }

      const debit = String(
        row.debit_account_id || ""
      ).trim();

      const credit = String(
        row.credit_account_id || ""
      ).trim();

      const amount = Number(
        row.amount || 0
      );

      const date = new Date(
        row.date ||
          row.created_at
      );

      /* ======================================================
         SAVINGS
      ====================================================== */

      if (
        credit ===
        SAVINGS_ACCOUNT
      ) {

        map[member].savings +=
          amount;

        map[
          member
        ].monthlySavings += amount;

        map[
          member
        ].savingsFrequency += 1;
      }

      if (
        debit === SAVINGS_ACCOUNT
      ) {

        map[member].savings -=
          amount;

        map[
          member
        ].withdrawalFrequency += 1;
      }

      /* ======================================================
         SHARES
      ====================================================== */

      if (
        credit === SHARES_ACCOUNT
      ) {
        map[member].shares +=
          amount;
      }

      if (
        debit === SHARES_ACCOUNT
      ) {
        map[member].shares -=
          amount;
      }

      /* ======================================================
         LOAN ISSUE
         A debit to 1011 (loan account) = new loan disbursed.
         This is the anchor date for the 30-day arrears clock.
      ====================================================== */

      if (
        debit === LOAN_ACCOUNT
      ) {

        map[
          member
        ].loanIssued += amount;

        map[
          member
        ].lastLoanIncreaseDate =
          date;
      }

      /* ======================================================
         PRINCIPAL PAYMENT
         A credit to 1011 = principal repayment received.
      ====================================================== */

      if (
        credit === LOAN_ACCOUNT
      ) {

        map[
          member
        ].loanPaid += amount;

        map[
          member
        ].lastPaymentDate =
          date;
      }

      /* ======================================================
         INTEREST PAYMENT
         A debit to 1020 (interest on loan) = interest accrued/charged.
         Only debits are counted per spec.
      ====================================================== */

      if (
        debit ===
        LOAN_INTEREST_ACCOUNT
      ) {

        map[
          member
        ].interestPaid += amount;

      }

      /* Credits to 1020 (interest repayments received) still
         update the last payment date so the arrears clock resets
         when a member pays interest. */
      if (
        credit ===
        LOAN_INTEREST_ACCOUNT
      ) {

        map[
          member
        ].lastPaymentDate =
          date;
      }

    });

    /* ======================================================
       FINAL PROCESSING
    ====================================================== */

    const now = new Date();

    const result = Object.values(
      map
    ).map((m) => {

      /* =========================
         BALANCE
      ========================= */

      const loanBalance =
        m.loanIssued -
        m.loanPaid;

      /* =========================
         REPAYMENT RATIO
      ========================= */

      const repaymentRatio =
        m.loanIssued > 0
          ? m.loanPaid /
            m.loanIssued
          : 0;

      /* =========================
         REFERENCE DATE
         Arrears clock starts 30 days after the most recent
         debit to 1011 (loan issue), unless a later payment
         (credit to 1011 or 1020) reset it.
      ========================= */

      let refDate =
        m.lastPaymentDate ||
        m.lastLoanIncreaseDate;

      /* =========================
         REFINANCE RESET
      ========================= */

      if (
        m.lastLoanIncreaseDate &&
        (!m.lastPaymentDate ||
          m.lastLoanIncreaseDate >
            m.lastPaymentDate)
      ) {

        refDate =
          m.lastLoanIncreaseDate;
      }

      /* =========================
         DPD
         arrearsDays = days past (refDate + 30)
      ========================= */

      let arrearsDays = 0;

      if (
        loanBalance > 0 &&
        refDate
      ) {

        const nextDue =
          new Date(refDate);

        nextDue.setDate(
          nextDue.getDate() +
            INSTALLMENT_DAYS
        );

        const dpd = Math.floor(
          (now - nextDue) /
            (1000 *
              60 *
              60 *
              24)
        );

        if (dpd > 0) {
          arrearsDays = dpd;
        }
      }

      /* =========================
         MEMBERSHIP MONTHS
      ========================= */

      const created =
        new Date(
          m.created_at || now
        );

      const membershipMonths =
        Math.max(
          1,
          Math.floor(
            (now - created) /
              (1000 *
                60 *
                60 *
                24 *
                30)
          )
        );

      /* =========================
         RUN RISK ENGINE
      ========================= */

      const risk =
        runRiskEngine({

          arrearsDays,

          repaymentRatio,

          missedPayments:
            Math.floor(
              arrearsDays / 30
            ),

          refinanceCount:
            m.refinanceCount,

          monthlySavings:
            m.monthlySavings,

          savingsFrequency:
            m.savingsFrequency,

          dormantMonths: 0,

          savingsTrend:
            "stable",

          loanBalance,

          totalSavings:
            m.savings,

          activeLoans: 1,

          membershipMonths,

          activityConsistency:
            80,

          monthlyIncome:
            Number(
              m.salary || 0
            ),

          monthlyInstallment:
            loanBalance / 12,

          existingDeductions: 0,

          withdrawalFrequency:
            m.withdrawalFrequency,

          suspiciousActivity:
            false,

          rapidWithdrawals:
            false,

        });

      return {

        ...m,

        totalSavings:
          m.savings,

        totalShares:
          m.shares,

        loanBalance,

        repaymentRatio,

        arrearsDays,

        parCategory:
          getParCategory(
            arrearsDays
          ),

        score: risk.score,

        riskLabel:
          risk.riskLabel,

      };
    });

    /* ======================================================
       SORT
    ====================================================== */

    result.sort((a, b) => {

      const A = Number(
        String(
          a.member_no || ""
        ).replace(/\D/g, "")
      );

      const B = Number(
        String(
          b.member_no || ""
        ).replace(/\D/g, "")
      );

      return A - B;
    });

    setMembers(result);

    setLoading(false);
  };

  /* ======================================================
     LOAD PENDING APPLICATIONS
  ====================================================== */

  const loadApplications = async () => {

    setAppsLoading(true);

    const { data, error } = await supabase
      .from("membership_applications")
      .select("*")
      .eq("status", "pending")
      .order("created_at", { ascending: false });

    if (!error) {
      setApplications(data || []);
    }

    setAppsLoading(false);
  };

  useEffect(() => {
    load();
    loadApplications();
  }, []);

  /* ======================================================
     APPROVE APPLICATION
     Runs entirely on the server (approve_membership_application):
     one transaction, next number from a database sequence, refuses
     duplicates, and is safe if clicked twice.
  ====================================================== */

  const approveApplication = async (app) => {

    if (busyId) return;
    setBusyId(app.id);
    setNotice("");

    try {
      const { data, error } = await supabase.rpc(
        "approve_membership_application",
        { p_app_id: String(app.id) }
      );

      if (error) {
        alert("Failed to approve: " + error.message);
        return;
      }

      if (!data?.ok) {
        alert(REASONS[data?.reason] || "Could not approve this application.");
        if (data?.reason === "ALREADY_PROCESSED") await loadApplications();
        return;
      }

      setNotice(
        data.existing
          ? `${app.name} is already a member (${data.member_no}). Application marked approved, no new member created.`
          : `${app.name} approved. Member number: ${data.member_no}. They activate with this number and their National ID.`
      );

      await loadApplications();
      await load();

    } finally {
      setBusyId(null);
    }
  };

  /* ======================================================
     REJECT APPLICATION
  ====================================================== */

  const rejectApplication = async (app) => {

    if (busyId) return;

    const confirmed = window.confirm(
      `Reject application from ${app.name}?`
    );

    if (!confirmed) return;

    setBusyId(app.id);

    try {
      const { error } = await supabase
        .from("membership_applications")
        .update({ status: "rejected" })
        .eq("id", app.id)
        .eq("status", "pending"); // never overwrite an application that was already approved

      if (error) {
        alert("Failed to reject application: " + error.message);
        return;
      }

      await loadApplications();

    } finally {
      setBusyId(null);
    }
  };

  /* ======================================================
     ADD MEMBER MANUALLY (also server-side)
  ====================================================== */

  const submitAddMember = async (e) => {
    e.preventDefault();

    if (addSaving) return;

    setAddError("");

    if (!addForm.name.trim()) {
      setAddError("Name is required.");
      return;
    }

    if (!/^\d{7,8}$/.test(addForm.national_id.trim())) {
      setAddError(REASONS.INVALID_NATIONAL_ID);
      return;
    }

    if (!addForm.email.trim()) {
      setAddError(REASONS.EMAIL_REQUIRED);
      return;
    }

    setAddSaving(true);

    const { data, error } = await supabase.rpc("admin_add_member", {
      p_name: addForm.name,
      p_national_id: addForm.national_id,
      p_email: addForm.email,
      p_phone: addForm.phone,
      p_branch: addForm.branch,
    });

    setAddSaving(false);

    if (error) {
      setAddError(error.message);
      return;
    }

    if (!data?.ok) {
      setAddError(REASONS[data?.reason] || "Could not add member.");
      return;
    }

    setAddForm({
      name: "",
      national_id: "",
      email: "",
      phone: "",
      branch: "",
    });

    setShowAddMember(false);
    setNotice(`Member added. Member number: ${data.member_no}.`);

    await load();
  };

  /* ======================================================
/* ======================================================
     EDIT MEMBER
     The record is identified by its immutable uuid `id`, never by
     member_no. Everything goes through admin_update_member(), which
     re-checks the caller's role, validates, follows a member-number
     change through every table that stores it, and writes the audit
     trail. Only fields that actually changed are sent.
  ====================================================== */

  const openEdit = () => {
    if (!selected?.id) return;
    setEditForm({
      member_no: selected.member_no || "",
      name: selected.name || "",
      national_id: selected.national_id || "",
      email: selected.email || "",
      phone: selected.phone || "",
      branch: selected.branch || "",
      occupation: selected.occupation || "",
      status: String(selected.status || "active").toLowerCase(),
      reason: "",
    });
    setEditError("");
    setEditing(true);
  };

  const closeEdit = () => {
    if (editSaving) return;
    setEditing(false);
    setEditError("");
  };

  const setEditField = (k, v) => setEditForm((f) => ({ ...f, [k]: v }));

  const submitEdit = async (e) => {
    e.preventDefault();

    if (editSaving || !selected) return;
    setEditError("");

    if (!selected.id) {
      setEditError("This record has no database id and cannot be edited.");
      return;
    }

    const changes = {};
    EDIT_FIELDS.forEach((k) => {
      if (normField(k, editForm[k]) !== normField(k, selected[k])) changes[k] = editForm[k];
    });

    if (!Object.keys(changes).length) {
      setEditError("Nothing was changed.");
      return;
    }

    if (!normField("name", editForm.name)) {
      setEditError(REASONS.NAME_REQUIRED);
      return;
    }

    if (changes.member_no) {
      if (String(editForm.reason || "").trim().length < 3) {
        setEditError("Give a reason for changing the member number. It is kept in the audit log.");
        return;
      }
      const sure = window.confirm(
        `Change member number ${selected.member_no} to ${normField("member_no", changes.member_no)}?\n\n` +
        "All of this member's savings, shares, loans and statements move to the new number, " +
        "and they must use the new number to log in."
      );
      if (!sure) return;
    }

    setEditSaving(true);

    const { data, error } = await supabase.rpc("admin_update_member", {
      p_id: selected.id,
      p_changes: changes,
      p_reason: changes.member_no ? String(editForm.reason).trim() : null,
    });

    setEditSaving(false);

    if (error) {
      setEditError(error.message);
      return;
    }

    if (!data?.ok) {
      setEditError(editErrorText(data));
      return;
    }

    const moved = Object.entries(data.updated_tables || {})
      .map(([t, n]) => `${t}: ${n}`)
      .join(", ");

    setNotice(
      data.member_no_changed
        ? `Member number changed to ${data.member_no}.${moved ? ` Records moved: ${moved}.` : ""}`
        : `${selected.name} updated.`
    );

    setEditing(false);
    setSelected(null);
    await load();
  };

/* ======================================================
     FILTER
  ====================================================== */

  const filtered = members.filter(
    (m) => {

      const q = String(
        searchText || ""
      )
        .toLowerCase()
        .trim();

      if (!q) return true;

      const value = String(
        m[searchType] || ""
      )
        .toLowerCase()
        .trim();

      return value.includes(q);
    }
  );

  /* ======================================================
     COLORS
  ====================================================== */

  const getRiskClass = (
    label
  ) => {

    if (label === "Excellent")
      return "excellent";

    if (label === "Very Good")
      return "verygood";

    if (label === "Good")
      return "good";

    if (label === "Fair")
      return "fair";

    if (label === "Poor")
      return "poor";

    return "verypoor";
  };

  const getDpdClass = (
    days
  ) => {

    if (days <= 0)
      return "good";

    if (days <= 30)
      return "warning";

    if (days <= 60)
      return "bad";

    return "danger";
  };

  /* ======================================================
     UI
  ====================================================== */

  return (
    <div className="members-page">

      {/* HEADER */}
      <div className="header">

        <h1>
          🏦 Member Registry
        </h1>

        <p>
          SACCO Intelligence
          Dashboard
        </p>

      </div>

      {loadError && (
        <p className="form-error" role="alert">{loadError}</p>
      )}

      {notice && (
        <p
          role="status"
          style={{ background: "#ecfdf5", color: "#065f46", padding: "10px 14px", borderRadius: 12, margin: "0 0 12px" }}
        >
          {notice}
        </p>
      )}

      {/* ACTION BAR */}
      <div className="action-bar">

        <button
          className="action-btn"
          onClick={() => setShowApplications(true)}
        >
          📥 Pending Applications
          {applications.length > 0 && (
            <span className="badge-count">
              {applications.length}
            </span>
          )}
        </button>

        <button
          className="action-btn"
          onClick={() => setShowAddMember(true)}
        >
          ➕ Add Member
        </button>

      </div>

      {/* SEARCH */}
      <div className="search-bar">

        <select
          value={searchType}
          onChange={(e) =>
            setSearchType(
              e.target.value
            )
          }
        >

          <option value="member_no">
            Member No
          </option>

          <option value="name">
            Name
          </option>

          <option value="phone">
            Phone
          </option>

          <option value="national_id">
            National ID
          </option>

        </select>

        <input
          type="text"
          placeholder={`Search by ${searchType}`}
          value={searchText}
          onChange={(e) =>
            setSearchText(
              e.target.value
            )
          }
        />

      </div>

      {/* TABLE */}
      <div className="table-wrapper">

        {loading ? (

          <div className="loading">
            <div className="loading-rows">
              {Array.from({ length: 8 }).map((_, i) => (
                <div className="loading-row" key={i} />
              ))}
            </div>
            <p className="loading-text">Loading members...</p>
          </div>

        ) : (

          <table className="members-table">

            <thead>

              <tr>

                <th>
                  Member No
                </th>

                <th>Name</th>

                <th>Savings</th>

                <th>Shares</th>

                <th>
                  Loan Balance
                </th>

                <th>DPD</th>

                <th>Score</th>

                <th>Risk</th>

              </tr>

            </thead>

            <tbody>

              {filtered.map((m) => (

                <tr
                  key={m.member_no}
                  className="clickable-row"
                  onClick={() =>
                    setSelected(m)
                  }
                >

                  <td>
                    {m.member_no}
                  </td>

                  <td>
                    {m.name}
                    {m.ledgerOnly && (
                      <span title="This member number has ledger entries but is not in the members table" style={{ marginLeft: 8, color: "#b45309", fontSize: 12 }}>
                        ⚠ not in registry
                      </span>
                    )}
                  </td>

                  <td>
                    {format(
                      m.totalSavings
                    )}
                  </td>

                  <td>
                    {format(
                      m.totalShares
                    )}
                  </td>

                  <td>
                    {format(
                      m.loanBalance
                    )}
                  </td>

                  <td>

                    <span
                      className={`dpd-badge ${getDpdClass(
                        m.arrearsDays
                      )}`}
                    >
                      {
                        m.arrearsDays
                      }
                    </span>

                  </td>

                  <td>
                    {m.score}
                  </td>

                  <td>

                    <span
                      className={`risk-badge ${getRiskClass(
                        m.riskLabel
                      )}`}
                    >
                      {
                        m.riskLabel
                      }
                    </span>

                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        )}

      </div>

      {/* ======================================================
         POPUP MEMBER CARD
      ====================================================== */}

      {selected && (

        <div className="popup-overlay">

          <div className="member-popup">

            {/* CLOSE */}
            <button
              className="close-btn"
              onClick={() =>
                setSelected(null)
              }
            >
              ✕
            </button>

            {/* PROFILE */}
            <div className="popup-header">

              <div className="avatar">

                {selected.name
                  ?.charAt(0)
                  ?.toUpperCase()}

              </div>

              <div>

                <h2>
                  {selected.name}
                </h2>

                <p>
                  {
                    selected.member_no
                  }
                </p>

              </div>

            </div>

            {/* DETAILS */}
            <div className="popup-body">

              {canEdit && selected.id && !selected.ledgerOnly && (
                <div className="edit-actions edit-actions-top">
                  <button type="button" className="action-btn" onClick={openEdit}>
                    ✏️ Edit member
                  </button>
                </div>
              )}

              <div className="detail-grid">

                <div className="detail-card">
                  <span>
                    Savings
                  </span>

                  <h3>
                    {format(
                      selected.totalSavings
                    )}
                  </h3>
                </div>

                <div className="detail-card">
                  <span>
                    Shares
                  </span>

                  <h3>
                    {format(
                      selected.totalShares
                    )}
                  </h3>
                </div>

                <div className="detail-card">
                  <span>
                    Loan Balance
                  </span>

                  <h3>
                    {format(
                      selected.loanBalance
                    )}
                  </h3>
                </div>

                <div className="detail-card">
                  <span>
                    Interest Due (1020)
                  </span>

                  <h3>
                    {format(
                      selected.interestPaid
                    )}
                  </h3>
                </div>

              </div>

              {/* RISK SECTION */}
              <div className="risk-section">

                <h3>
                  Risk Analysis
                </h3>

                <div
                  className={`risk-big ${getRiskClass(
                    selected.riskLabel
                  )}`}
                >
                  {
                    selected.riskLabel
                  }
                </div>

                <div className="score-big">
                  <span className="gauge-value">
                    Score: {selected.score}
                  </span>
                  <div className="gauge-track">
                    <div
                      className="gauge-fill"
                      style={{
                        width: `${Math.min(100, Math.max(0, Number(selected.score) || 0))}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="par-box">

                  PAR:
                  {" "}
                  {
                    selected.parCategory
                  }

                </div>

                <div
                  className={`dpd-big ${getDpdClass(
                    selected.arrearsDays
                  )}`}
                >

                  {
                    selected.arrearsDays
                  }
                  {" "}
                  Days In Arrears

                </div>

              </div>

              {/* PERSONAL DETAILS */}
              <div className="personal-section">

                <h3>
                  Member Details
                </h3>

                <p>
                  📞
                  {" "}
                  {
                    selected.phone
                  }
                </p>

                <p>
                  🆔
                  {" "}
                  {
                    selected.national_id
                  }
                </p>

                <p>
                  📧
                  {" "}
                  {
                    selected.email
                  }
                </p>

                <p>
                  💼
                  {" "}
                  {
                    selected.occupation
                  }
                </p>

              </div>

            </div>

          </div>

        </div>

      )}

      {/* ======================================================
         EDIT MEMBER MODAL
      ====================================================== */}

      {editing && selected && (() => {
        const memberNoChanged =
          normField("member_no", editForm.member_no) !== normField("member_no", selected.member_no);
        const activated = !!(selected.auth_user_id || selected.auth_id);
        const currentStatus = String(selected.status || "").toLowerCase();
        const statusOptions =
          currentStatus && !STATUS_OPTIONS.includes(currentStatus)
            ? [currentStatus, ...STATUS_OPTIONS]
            : STATUS_OPTIONS;

        return (
          <div className="popup-overlay">
            <div className="member-popup add-member-popup edit-member-popup">

              <button className="close-btn" onClick={closeEdit} aria-label="Close">✕</button>

              <div className="popup-header">
                <div>
                  <h2>Edit Member</h2>
                  <p>{selected.member_no} · {selected.name}</p>
                </div>
              </div>

              <div className="popup-body">
                <form className="add-member-form" onSubmit={submitEdit}>

                  <label>
                    Member Number {isAdmin ? "*" : "(administrator only)"}
                    <input
                      type="text"
                      value={editForm.member_no}
                      disabled={!isAdmin || editSaving}
                      maxLength={20}
                      onChange={(e) =>
                        setEditField("member_no", e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, ""))
                      }
                    />
                  </label>

                  {memberNoChanged && (
                    <>
                      <div className="warn-box" role="alert">
                        Changing the member number moves all of this member&apos;s savings, shares, loans and
                        statements to the new number. They must use the new number to log in.
                      </div>
                      <label>
                        Reason for the change *
                        <input
                          type="text"
                          value={editForm.reason}
                          disabled={editSaving}
                          placeholder="e.g. Renumbered after branch merge"
                          onChange={(e) => setEditField("reason", e.target.value)}
                        />
                      </label>
                    </>
                  )}

                  <label>
                    Full Name *
                    <input
                      type="text"
                      value={editForm.name}
                      disabled={editSaving}
                      onChange={(e) => setEditField("name", e.target.value)}
                    />
                  </label>

                  <label>
                    National ID {isAdmin ? "" : "(administrator only)"}
                    <input
                      type="text"
                      value={editForm.national_id}
                      disabled={!isAdmin || editSaving}
                      inputMode="numeric"
                      maxLength={8}
                      onChange={(e) => setEditField("national_id", e.target.value.replace(/\D/g, ""))}
                    />
                  </label>

                  <label>
                    Email {isAdmin ? "" : "(administrator only)"}
                    <input
                      type="email"
                      value={editForm.email}
                      disabled={!isAdmin || activated || editSaving}
                      onChange={(e) => setEditField("email", e.target.value)}
                    />
                    {activated && (
                      <small className="field-hint">
                        Locked: this member has activated their account and signs in with this email.
                      </small>
                    )}
                  </label>

                  <div className="form-row">
                    <label>
                      Phone
                      <input
                        type="text"
                        value={editForm.phone}
                        disabled={editSaving}
                        onChange={(e) => setEditField("phone", e.target.value)}
                      />
                    </label>
                    <label>
                      Branch
                      <input
                        type="text"
                        value={editForm.branch}
                        disabled={editSaving}
                        onChange={(e) => setEditField("branch", e.target.value)}
                      />
                    </label>
                  </div>

                  <div className="form-row">
                    <label>
                      Occupation
                      <input
                        type="text"
                        value={editForm.occupation}
                        disabled={editSaving}
                        onChange={(e) => setEditField("occupation", e.target.value)}
                      />
                    </label>
                    <label>
                      Status {isAdmin ? "" : "(admin only)"}
                      <select
                        value={editForm.status}
                        disabled={!isAdmin || editSaving}
                        onChange={(e) => setEditField("status", e.target.value)}
                      >
                        {statusOptions.map((o) => (
                          <option key={o} value={o}>{o}</option>
                        ))}
                      </select>
                    </label>
                  </div>

                  {editError && <p className="form-error" role="alert">{editError}</p>}

                  <div className="edit-actions">
                    <button type="button" className="cancel-btn" onClick={closeEdit} disabled={editSaving}>
                      Cancel
                    </button>
                    <button type="submit" className="save-btn" disabled={editSaving}>
                      {editSaving ? "Saving..." : "Save changes"}
                    </button>
                  </div>

                </form>
              </div>

            </div>
          </div>
        );
      })()}

      {/* ======================================================
         PENDING APPLICATIONS PANEL
      ====================================================== */}

      {showApplications && (

        <div className="popup-overlay">

          <div className="member-popup applications-popup">

            <button
              className="close-btn"
              onClick={() => setShowApplications(false)}
            >
              ✕
            </button>

            <div className="popup-header">
              <div>
                <h2>Pending Applications</h2>
                <p>{applications.length} awaiting review</p>
              </div>
            </div>

            <div className="popup-body">

              {appsLoading ? (
                <p className="loading-text">Loading applications...</p>
              ) : applications.length === 0 ? (
                <p className="loading-text">No pending applications.</p>
              ) : (

                <table className="members-table">

                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>National ID</th>
                      <th>Phone</th>
                      <th>Email</th>
                      <th>Branch</th>
                      <th>Actions</th>
                    </tr>
                  </thead>

                  <tbody>
                    {applications.map((app) => (
                      <tr key={app.id}>
                        <td>{app.name}</td>
                        <td>{app.national_id}</td>
                        <td>{app.phone}</td>
                        <td>{app.email}</td>
                        <td>{app.branch || "—"}</td>
                        <td>
                          <div className="row-actions">
                            <button
                              className="approve-btn"
                              disabled={!!busyId}
                              onClick={() => approveApplication(app)}
                            >
                              Approve
                            </button>
                            <button
                              className="reject-btn"
                              disabled={!!busyId}
                              onClick={() => rejectApplication(app)}
                            >
                              Reject
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>

                </table>
              )}

            </div>

          </div>

        </div>

      )}

      {/* ======================================================
         ADD MEMBER MODAL
      ====================================================== */}

      {showAddMember && (

        <div className="popup-overlay">

          <div className="member-popup add-member-popup">

            <button
              className="close-btn"
              onClick={() => setShowAddMember(false)}
            >
              ✕
            </button>

            <div className="popup-header">
              <h2>Add New Member</h2>
            </div>

            <div className="popup-body">

              <form className="add-member-form" onSubmit={submitAddMember}>

                <label>
                  Full Name *
                  <input
                    type="text"
                    value={addForm.name}
                    onChange={(e) =>
                      setAddForm({ ...addForm, name: e.target.value })
                    }
                    required
                  />
                </label>

                <label>
                  National ID *
                  <input
                    type="text"
                    value={addForm.national_id}
                    required
                    inputMode="numeric"
                    maxLength={8}
                    onChange={(e) =>
                      setAddForm({ ...addForm, national_id: e.target.value.replace(/\D/g, "") })
                    }
                  />
                </label>

                <label>
                  Phone
                  <input
                    type="text"
                    value={addForm.phone}
                    onChange={(e) =>
                      setAddForm({ ...addForm, phone: e.target.value })
                    }
                  />
                </label>

                <label>
                  Email *
                  <input
                    type="email"
                    required
                    value={addForm.email}
                    onChange={(e) =>
                      setAddForm({ ...addForm, email: e.target.value })
                    }
                  />
                </label>

                <label>
                  Branch
                  <input
                    type="text"
                    value={addForm.branch}
                    onChange={(e) =>
                      setAddForm({ ...addForm, branch: e.target.value })
                    }
                  />
                </label>

                {addError && <p className="form-error">{addError}</p>}

                <button
                  type="submit"
                  className="save-btn"
                  disabled={addSaving}
                >
                  {addSaving ? "Saving..." : "Save Member"}
                </button>

              </form>

            </div>

          </div>

        </div>

      )}

    </div>
  );
}