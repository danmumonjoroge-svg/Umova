// src/pos-erp/pages/workspaces/MoreWorkspace.jsx
//
// The "More" tab (brief section 3). On a phone the bottom bar only fits
// five destinations, so every other module lives here -- the primary way a
// phone user reaches Retail, Rentals, Salon and Messages. Also holds
// Settings, Audit and Sign out.
//
// Layout: GROUP CARDS. Each module is one parent card (its header opens the
// module's workspace) holding its pages as small sub-cards. Modules with no
// pages of their own are gathered into one "Other tools" card, and the
// admin pages are grouped by purpose (Day-to-day, Team, Oversight).
// Everything still comes from navConfig, so it can never drift out of step
// with the sidebar: a page not named in ADMIN_GROUPS lands in "Other" rather
// than disappearing.

import React from 'react';
import { LogOut, SlidersHorizontal, CalendarCheck, UsersRound, ShieldCheck, Settings, LayoutGrid } from 'lucide-react';
import { usePosErpAuth } from '../../auth/usePosErpAuth';
import { useCapabilities } from '../../navigation/CapabilitiesContext';
import { usePermissions } from '../../navigation/PermissionsContext';
import { MODULES, visibleModules, visibleChildren } from '../../navigation/navConfig';
import { WorkspacePage, SectionTitle, GroupCard, SubCard, accentFor } from '../../components/workspace/WorkspaceKit';

// How the pages under More are grouped (by route). Anything not listed falls into "Other".
const ADMIN_GROUPS = [
  { key: 'day',    title: 'Day to day', blurb: 'Close the day, fix a sale', icon: CalendarCheck, paths: ['/pos/reconcile', '/pos/reversals'] },
  { key: 'team',   title: 'Team',       blurb: 'Staff, records and pay',    icon: UsersRound,    paths: ['/pos/staff', '/pos/hr', '/pos/payroll'] },
  { key: 'checks', title: 'Oversight',  blurb: 'Reports and audit trail',   icon: ShieldCheck,   paths: ['/pos/control', '/pos/audit'] },
];

const GRID = 'grid grid-cols-1 md:grid-cols-2 gap-3 items-start';

export default function MoreWorkspace() {
  const { staffName, role, tenant, logout } = usePosErpAuth();
  const { enabled } = useCapabilities();
  const { canAny } = usePermissions();

  // Everything that is not a bottom-bar tab and not More itself.
  const others = visibleModules(enabled, canAny).filter((m) => !m.tab);
  const more = MODULES.find((m) => m.key === 'more');

  // Modules with pages get their own card; the rest share one "Other tools" card.
  const withPages = others.map((m) => ({ m, kids: visibleChildren(m, enabled, canAny) })).filter((x) => x.kids.length > 0);
  const singles = others.filter((m) => visibleChildren(m, enabled, canAny).length === 0);

  // Admin pages, bucketed.
  const adminPages = visibleChildren(more, enabled, canAny).filter((c) => c.to !== '/pos/settings');
  const placed = new Set(ADMIN_GROUPS.flatMap((g) => g.paths));
  const adminGroups = ADMIN_GROUPS
    .map((g) => ({ ...g, items: g.paths.map((p) => adminPages.find((c) => c.to === p)).filter(Boolean) }))
    .filter((g) => g.items.length > 0);
  const leftovers = adminPages.filter((c) => !placed.has(c.to));
  const hasSettingsPage = visibleChildren(more, enabled, canAny).some((c) => c.to === '/pos/settings');

  return (
    <WorkspacePage title="More" subtitle={tenant?.business_name ? `${tenant.business_name}${staffName ? ` · ${staffName}` : ''}${role ? ` (${role})` : ''}` : undefined}>
      <SectionTitle>Your business</SectionTitle>
      <div className={GRID}>
        {withPages.map(({ m, kids }) => (
          <GroupCard key={m.key} to={m.to} icon={m.icon} title={m.label} blurb={m.blurb} accent={accentFor(m.key)}>
            {kids.map((c) => <SubCard key={c.to} to={c.to} icon={c.icon} title={c.label} />)}
          </GroupCard>
        ))}
        {singles.length > 0 && (
          <GroupCard icon={LayoutGrid} title="Other tools" blurb="Single-page tools" accent={accentFor('more')}>
            {singles.map((m) => <SubCard key={m.key} to={m.to} icon={m.icon} title={m.label} desc={m.blurb} />)}
          </GroupCard>
        )}
      </div>

      <SectionTitle>Manage</SectionTitle>
      <div className={GRID}>
        {adminGroups.map((g) => (
          <GroupCard key={g.key} icon={g.icon} title={g.title} blurb={g.blurb} accent={accentFor('more')}>
            {g.items.map((c) => <SubCard key={c.to} to={c.to} icon={c.icon} title={c.label} />)}
          </GroupCard>
        ))}
        {leftovers.length > 0 && (
          <GroupCard icon={LayoutGrid} title="Other" accent={accentFor('more')}>
            {leftovers.map((c) => <SubCard key={c.to} to={c.to} icon={c.icon} title={c.label} />)}
          </GroupCard>
        )}
        <GroupCard icon={Settings} title="Settings" blurb="Your business and your menu" accent={accentFor('more')}>
          {hasSettingsPage && <SubCard to="/pos/settings" icon={Settings} title="Settings" />}
          <SubCard to="/pos/settings" icon={SlidersHorizontal} title="What my business does" desc="Choose what shows in your menu" />
        </GroupCard>
      </div>

      <button
        onClick={logout}
        className="mt-5 w-full flex items-center justify-center gap-2 min-h-[44px] bg-white border border-[#DDE3DD] rounded-lg text-[13px] font-semibold text-[#26352D] hover:bg-[#F7F6F0]"
      >
        <LogOut size={16} /> Sign out
      </button>
    </WorkspacePage>
  );
}
