// supabase/functions/_shared/etims.ts
//
// Shared by every etims-* Edge Function. MULTI-TENANT RULES ENFORCED HERE, ONCE:
//   1. The tenant and business come from the caller's verified login (JWT claims), NEVER from the request body.
//   2. KRA credentials are loaded by that business_id only (etims_get_key). No environment-variable key, no platform key,
//      no fallback: a business without its own key gets NOT_CONFIGURED.
//   3. The KRA address is chosen by the business's own environment. Paths and payloads are NOT here: they come from the
//      KRA Technical Specifications (Phase 3b) and are deliberately not guessed.
//   4. Errors returned to the browser are short and never contain a key, header or raw KRA body.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
export const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, { auth: { persistSession: false } });

// Base addresses as published on KRA's eTIMS pages (step-by-step guide).
export const KRA_BASE: Record<string, string> = {
  sandbox: "https://etims-api-sbx.kra.go.ke",
  production: "https://etims-api.kra.go.ke",
};

const ALLOWED_ORIGINS = (Deno.env.get("ETIMS_ALLOWED_ORIGINS") || "").split(",").map((s) => s.trim()).filter(Boolean);
export function cors(req: Request) {
  const origin = req.headers.get("Origin") || "";
  const ok = ALLOWED_ORIGINS.length === 0 ? false : ALLOWED_ORIGINS.includes(origin);   // unset = no cross-origin browser access
  return {
    "Access-Control-Allow-Origin": ok ? origin : "null",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}
export const json = (req: Request, body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors(req), "Content-Type": "application/json" } });

function jwtClaims(authHeader: string): Record<string, unknown> | null {
  try {
    const t = authHeader.replace(/^Bearer\s+/i, "");
    const p = t.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(atob(p));
  } catch { return null; }
}

export interface Caller { tenantId: string; staffId: string | null; businessId: string; config: Record<string, any>; }

/** Verifies the login with Supabase, then resolves THIS caller's business. Throws {status, code} on any problem. */
export async function resolveCaller(req: Request, perm = "settings.manage"): Promise<Caller> {
  const authHeader = req.headers.get("Authorization") || "";
  if (!authHeader) throw { status: 401, code: "NO_LOGIN" };
  const userClient = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: authHeader } }, auth: { persistSession: false },
  });
  const { data: u, error } = await userClient.auth.getUser();
  if (error || !u?.user) throw { status: 401, code: "BAD_LOGIN" };
  const c = jwtClaims(authHeader) || {};
  const tenantId = String(c["pos_tenant_id"] || (c["app_metadata"] as any)?.pos_tenant_id || "");
  if (!tenantId) throw { status: 403, code: "NO_TENANT" };
  const staffId = (c["pos_staff_id"] as string) || null;

  // Same rule as pos_require() in the database: a staff session must hold the permission, checked by the database
  // against THIS login (never trusted from the browser). Sessions without a staff id (the owner login) pass.
  if (staffId) {
    const { data: ok, error: pe } = await userClient.rpc("pos_has_permission", { p_perm: perm });
    if (pe || ok !== true) throw { status: 403, code: "NO_PERMISSION" };
  }
  const { data: biz } = await admin.from("lb_businesses").select("id").eq("tenant_id", tenantId).maybeSingle();
  if (!biz) throw { status: 403, code: "NO_BUSINESS" };
  const { data: config } = await admin.from("lb_etims_config").select("*").eq("business_id", biz.id).maybeSingle();
  if (!config || config.tenant_id !== tenantId) throw { status: 409, code: "NOT_CONFIGURED" };
  return { tenantId, staffId, businessId: biz.id, config };
}

/** THIS business's own key. Never falls back to anything else. */
export async function loadOwnKey(businessId: string): Promise<string> {
  const { data } = await admin.rpc("etims_get_key", { p_business: businessId });
  if (!data) throw { status: 409, code: "NOT_CONFIGURED" };
  return data as string;
}

export function failure(req: Request, e: any) {
  const status = e?.status || 500;
  console.error("[etims]", e?.code || e?.message || "error");     // code only: never log bodies, headers or keys
  return json(req, { ok: false, code: e?.code || "SERVER_ERROR" }, status);
}
